<?php
// Koneksi ke database
$conn = new mysqli("localhost", "root", "", "inventory_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query untuk mengambil data produk beserta kategori dan supplier
$sql = "SELECT p.id_product, p.product_name, p.price, p.stock, c.category_name, s.name AS supplier_name
        FROM product p
        JOIN category c ON p.id_category = c.id_category
        JOIN supplier s ON p.id_supplier = s.id_supplier";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Products</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1>Product List</h1>
        <table border="1">
            <tr>
                <th>ID</th>
                <th>Product Name</th>
                <th>Price</th>
                <th>Stock</th>
                <th>Category</th>
                <th>Supplier</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['id_product']; ?></td>
                    <td><?php echo $row['product_name']; ?></td>
                    <td><?php echo number_format($row['price'], 2); ?></td>
                    <td><?php echo $row['stock']; ?></td>
                    <td><?php echo $row['category_name']; ?></td>
                    <td><?php echo $row['supplier_name']; ?></td>
                </tr>
            <?php endwhile; ?>
        </table>
    </div>
</body>
</html>