<?php
// Koneksi ke database
$conn = new mysqli("localhost", "root", "", "inventory_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $category_name = $_POST['category_name'];

    // Validasi input agar tidak kosong
    if (!empty($category_name)) {
        $sql = "INSERT INTO category (category_name) VALUES ('$category_name')";
        if ($conn->query($sql) === TRUE) {
            echo "<p>Category added successfully!</p>";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "<p>Please enter a valid category name.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Category</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1>Add New Category</h1>
        <form method="POST" action="">
            <label for="category_name">Category Name:</label>
            <input type="text" id="category_name" name="category_name" required>
            
            <button type="submit">Add Category</button>
        </form>
    </div>
</body>
</html>