<?php
// Koneksi ke database
$conn = new mysqli("localhost", "root", "", "inventory_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_product = $_POST['id_product'];
    $quantity = $_POST['quantity'];
    $date = $_POST['date'];
    $id_supplier = $_POST['id_supplier'];

    // Validasi input
    if (!empty($id_product) && !empty($quantity) && !empty($date) && !empty($id_supplier)) {
        // Tambahkan transaksi masuk
        $sql_incoming = "INSERT INTO incoming_trans (id_product, quantity, date, id_supplier)
                         VALUES ('$id_product', '$quantity', '$date', '$id_supplier')";
        if ($conn->query($sql_incoming) === TRUE) {
            // Update stok produk
            $sql_update_stock = "UPDATE product SET stock = stock + $quantity WHERE id_product = $id_product";
            if ($conn->query($sql_update_stock) === TRUE) {
                echo "<p>Incoming transaction recorded successfully!</p>";
            } else {
                echo "Error updating stock: " . $conn->error;
            }
        } else {
            echo "Error: " . $sql_incoming . "<br>" . $conn->error;
        }
    } else {
        echo "<p>Please fill in all fields.</p>";
    }
}

// Ambil data produk dan supplier untuk dropdown
$sql_products = "SELECT * FROM product";
$result_products = $conn->query($sql_products);

$sql_suppliers = "SELECT * FROM supplier";
$result_suppliers = $conn->query($sql_suppliers);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Incoming Transaction</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1>Incoming Transaction</h1>
        <form method="POST" action="">
            <label for="id_product">Product:</label>
            <select id="id_product" name="id_product" required>
                <?php while ($row = $result_products->fetch_assoc()): ?>
                    <option value="<?php echo $row['id_product']; ?>">
                        <?php echo $row['product_name']; ?>
                    </option>
                <?php endwhile; ?>
            </select>

            <label for="quantity">Quantity:</label>
            <input type="number" id="quantity" name="quantity" min="1" required>

            <label for="date">Date:</label>
            <input type="date" id="date" name="date" required>

            <label for="id_supplier">Supplier:</label>
            <select id="id_supplier" name="id_supplier" required>
                <?php while ($row = $result_suppliers->fetch_assoc()): ?>
                    <option value="<?php echo $row['id_supplier']; ?>">
                        <?php echo $row['name']; ?>
                    </option>
                <?php endwhile; ?>
            </select>

            <button type="submit">Add Incoming Transaction</button>
        </form>
    </div>
</body>
</html>