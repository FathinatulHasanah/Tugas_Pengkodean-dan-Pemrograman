<?php
// Koneksi ke database
$conn = new mysqli("localhost", "root", "", "inventory_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $product_name = $_POST['product_name'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $id_category = $_POST['id_category'];
    $id_supplier = $_POST['id_supplier'];

    // Validasi input
    if (!empty($product_name) && !empty($price) && !empty($stock) && !empty($id_category) && !empty($id_supplier)) {
        $sql = "INSERT INTO product (product_name, price, stock, id_category, id_supplier)
                VALUES ('$product_name', '$price', '$stock', '$id_category', '$id_supplier')";
        if ($conn->query($sql) === TRUE) {
            echo "<p>Product added successfully!</p>";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "<p>Please fill in all fields.</p>";
    }
}

// Ambil data kategori dan supplier untuk dropdown
$sql_categories = "SELECT * FROM category";
$result_categories = $conn->query($sql_categories);

$sql_suppliers = "SELECT * FROM supplier";
$result_suppliers = $conn->query($sql_suppliers);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1>Add New Product</h1>
        <form method="POST" action="">
            <label for="product_name">Product Name:</label>
            <input type="text" id="product_name" name="product_name" required>

            <label for="price">Price:</label>
            <input type="number" step="0.01" id="price" name="price" required>

            <label for="stock">Stock:</label>
            <input type="number" id="stock" name="stock" required>

            <label for="id_category">Category:</label>
            <select id="id_category" name="id_category" required>
                <?php while ($row = $result_categories->fetch_assoc()): ?>
                    <option value="<?php echo $row['id_category']; ?>">
                        <?php echo $row['category_name']; ?>
                    </option>
                <?php endwhile; ?>
            </select>

            <label for="id_supplier">Supplier:</label>
            <select id="id_supplier" name="id_supplier" required>
                <?php while ($row = $result_suppliers->fetch_assoc()): ?>
                    <option value="<?php echo $row['id_supplier']; ?>">
                        <?php echo $row['name']; ?>
                    </option>
                <?php endwhile; ?>
            </select>

            <button type="submit">Add Product</button>
        </form>
    </div>
</body>
</html>