<?php
$conn = new mysqli("localhost", "root", "", "inventory_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $address = $_POST['address'];
    $phone = $_POST['phone'];

    $sql = "INSERT INTO supplier (name, address, phone) VALUES ('$name', '$address', '$phone')";
    if ($conn->query($sql) === TRUE) {
        echo "<p>Supplier added successfully!</p>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Supplier</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1>Add New Supplier</h1>
        <form method="POST" action="">
            <label for="name">Supplier Name:</label>
            <input type="text" id="name" name="name" required>
            
            <label for="address">Address:</label>
            <textarea id="address" name="address" required></textarea>
            
            <label for="phone">Phone:</label>
            <input type="text" id="phone" name="phone" required>
            
            <button type="submit">Add Supplier</button>
        </form>
    </div>
</body>
</html>