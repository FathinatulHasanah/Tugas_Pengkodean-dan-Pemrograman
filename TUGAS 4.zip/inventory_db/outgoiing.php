<?php
// Koneksi ke database
$conn = new mysqli("localhost", "root", "", "inventory_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_product = $_POST['id_product'];
    $quantity = $_POST['quantity'];
    $date = $_POST['date'];

    // Validasi input
    if (!empty($id_product) && !empty($quantity) && !empty($date)) {
        // Cek stok produk
        $sql_check_stock = "SELECT stock FROM product WHERE id_product = $id_product";
        $result_stock = $conn->query($sql_check_stock);
        $row_stock = $result_stock->fetch_assoc();

        if ($row_stock['stock'] >= $quantity) {
            // Tambahkan transaksi keluar
            $sql_outgoing = "INSERT INTO outgoing_trans (id_product, quantity, date)
                             VALUES ('$id_product', '$quantity', '$date')";
            if ($conn->query($sql_outgoing) === TRUE) {
                // Update stok produk
                $sql_update_stock = "UPDATE product SET stock = stock - $quantity WHERE id_product = $id_product";
                if ($conn->query($sql_update_stock) === TRUE) {
                    echo "<p>Outgoing transaction recorded successfully!</p>";
                } else {
                    echo "Error updating stock: " . $conn->error;
                }
            } else {
                echo "Error: " . $sql_outgoing . "<br>" . $conn->error;
            }
        } else {
            echo "<p>Insufficient stock for this product.</p>";
        }
    } else {
        echo "<p>Please fill in all fields.</p>";
    }
}

// Ambil data produk untuk dropdown
$sql_products = "SELECT * FROM product";
$result_products = $conn->query($sql_products);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Outgoing Transaction</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1>Outgoing Transaction</h1>
        <form method="POST" action="">
            <label for="id_product">Product:</label>
            <select id="id_product" name="id_product" required>
                <?php while ($row = $result_products->fetch_assoc()): ?>
                    <option value="<?php echo $row['id_product']; ?>">
                        <?php echo $row['product_name']; ?>
                    </option>
                <?php endwhile; ?>
            </select>

            <label for="quantity">Quantity:</label>
            <input type="number" id="quantity" name="quantity" min="1" required>

            <label for="date">Date:</label>
            <input type="date" id="date" name="date" required>

            <button type="submit">Add Outgoing Transaction</button>
        </form>
    </div>
</body>
</html>