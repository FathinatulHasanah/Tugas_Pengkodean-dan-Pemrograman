// Validasi form sebelum submit
document.addEventListener("DOMContentLoaded", function () {
    const forms = document.querySelectorAll("form");

    forms.forEach((form) => {
        form.addEventListener("submit", function (event) {
            let isValid = true;

            // Loop melalui semua input dalam form
            const inputs = form.querySelectorAll("input, select, textarea");
            inputs.forEach((input) => {
                if (input.hasAttribute("required") && !input.value.trim()) {
                    isValid = false;
                    alert(`Please fill in the field: ${input.name}`);
                    input.focus();
                }
            });

            // Cegah pengiriman jika ada input yang tidak valid
            if (!isValid) {
                event.preventDefault();
            }
        });
    });
});

// Fungsi untuk membatasi input hanya angka (misalnya untuk quantity)
function restrictToNumbers(inputElement) {
    inputElement.addEventListener("input", function () {
        this.value = this.value.replace(/[^0-9]/g, ""); // Hanya izinkan angka
    });
}

// Contoh penggunaan untuk input quantity
document.querySelectorAll("input[type='number']").forEach((input) => {
    restrictToNumbers(input);
});