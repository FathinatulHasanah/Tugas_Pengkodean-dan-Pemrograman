CREATE TABLE supplier (
    id_supplier INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    address TEXT,
    phone VARCHAR(15)
);

CREATE TABLE category (
    id_category INT AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(50) NOT NULL
);

CREATE TABLE product (
    id_product INT AUTO_INCREMENT PRIMARY KEY,
    product_name VARCHAR(100) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    stock INT NOT NULL DEFAULT 0,
    id_category INT NOT NULL,
    id_supplier INT NOT NULL,
    FOREIGN KEY (id_category) REFERENCES category(id_category),
    FOREIGN KEY (id_supplier) REFERENCES supplier(id_supplier)
);

CREATE TABLE incoming_trans (
    id_incoming INT AUTO_INCREMENT PRIMARY KEY,
    id_product INT NOT NULL,
    quantity INT NOT NULL,
    date DATE NOT NULL,
    id_supplier INT NOT NULL,
    FOREIGN KEY (id_product) REFERENCES product(id_product),
    FOREIGN KEY (id_supplier) REFERENCES supplier(id_supplier)
);

CREATE TABLE outgoing_trans (
    id_outgoing INT AUTO_INCREMENT PRIMARY KEY,
    id_product INT NOT NULL,
    quantity INT NOT NULL,
    date DATE NOT NULL,
    FOREIGN KEY (id_product) REFERENCES product(id_product)
);