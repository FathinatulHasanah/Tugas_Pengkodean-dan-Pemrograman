<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory App</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1>Inventory Management System</h1>
        <nav>
            <ul>
                <li><a href="add_supplier.php">Add Supplier</a></li>
                <li><a href="add_category.php">Add Category</a></li>
                <li><a href="add_product.php">Add Product</a></li>
                <li><a href="incoming.php">Incoming Transaction</a></li>
                <li><a href="outgoing.php">Outgoing Transaction</a></li>
                <li><a href="view_products.php">View Products</a></li>
            </ul>
        </nav>
    </div>
</body>
</html>